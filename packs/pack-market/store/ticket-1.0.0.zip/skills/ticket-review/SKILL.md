---
name: ticket-review
description: >-
  Review by talking to the worker: ask it to re-examine its own delivery. It is not a checklist and it
  is not you redoing the work. Ask three things: what changed, why is it done, what is still missing.
  The worker answers, you decide whether it is worth handing to the user. If it cannot answer, ask
  again, grant a new round, or close the ticket. Use after a ticket reports delivered.
---

# ticket-review —— 审查就是对话

主人的要求很朴素：**主代理跟子代理说话，叫它自己审**。所以这里没有关卡、没有打分表、
没有"根据不够"这种判断——工具也不做这件事。要做的是问，然后是听。

## 一、三次提问（每次都是一条 `ticket_say_payload` 的 text）

1. **你改了什么**
   `把你这次改动逐条列出来：文件/分支/记录编号/URL，各自一句话说明改了什么。只列你确实动过的。`
2. **你凭什么说做完了**
   `给出可复核的证据：跑了什么命令、结果是什么、目标里要求的每一项对应到哪条证据。命令可以重跑的话，写下怎么重跑。`
3. **还差什么**
   `对照目标原文，列出还没做到的部分和它需要什么（更多时间、别的工具、一个决定）。没有就明确说没有。`

第三问最关键：一个"没有还差什么"的回答，比一百字的"已完成"可靠得多，因为它把目标原文
重新摆回 worker 眼前对照了一遍。

## 二、听完之后，你只有三种出路

| 情况 | 动作 |
|---|---|
| 证据对得上目标 | 交付给主人一行：结论 + 产物在哪 + worker 自己列的证据。想留痕就 `ticket_stop` 关掉这张票 |
| 差东西但能补 | `ticket_grant` 追加预算，或者 `ticket_say_payload` 再问一轮（补的是事实，不是要求） |
| 差东西且不可补 | 照实说：`这张票没做成，差 <那一件>` —— 不要替它圆 |

## 三、两条别做

- **不要自己重做它的活来"验证"**。那既不省你的时间，又把票搞脏（你改了东西，worker 的声明和现状就对不上了）。要验证就让它给可重跑的命令，你自己跑那条命令——这是同一件事，代价完全不同。
- **不要把复查变成第二次任务**。你问的是"你怎么证明"，不是"再优化一下"。加需求就走新票或 `ticket_grant`，别混在回话里。

## 四、什么时候值得多问一轮

worker 的第 2、3 问回答含糊时（没有命令、没有对应关系、"应该没问题"），**再问一次同样的话**。
同一个问题第二次回答更具体，通常就说明第一次是蒙的；两次都含糊，就直接把这一点交给主人，
比你自己判断更诚实。
