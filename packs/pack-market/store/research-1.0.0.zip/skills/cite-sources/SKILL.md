---
name: cite-sources
description: >-
  Every claim in the deliverable carries a source that can be traced back: find the source, verify it
  three ways, mark it in the required format, and label what cannot be found as missing rather than
  inventing it. Use when writing anything that will be checked, or when the user asks for citations or
  references.
---

# cite-sources —— 带引用的交付

目标:交付物可以被读者**逐条复核**。引用是证据指针,不是装饰。

## 流程

1. **列出主张**:把稿子里的事实性主张逐条抽出来(数字、结论、方法、年份);
2. **给每条找源**:
   - 你**读过原文**(全文或摘要)→ 标注来源,注明访问深度;
   - 只见过转述 → 找到一手来源再引;找不到一手就标
     `〔转述:未核原文〕`;
   - 根本没有源 → **删掉这条主张**,或改写成"尚无定论/我不知道";
3. **核对三查**(每条引用过一遍):
   - **存在**:标题/作者/DOI 是否真的存在;
   - **相符**:来源里的内容与你引用它的语境一致(别拿相关当因果);
   - **卷期年份**:页码、卷期、年份抄录无误;
4. **格式**:跟随目标场合 —— 学术稿用 BibTeX/IEEE 逐条列出;报告用
   `[n] 作者, 标题, 出处, 年份`;内部文档可一行 `标题 (URL, 访问日期)`。

## 诚实标注(必须)

| 情况 | 标注 |
|---|---|
| 只读了摘要 | `(仅读摘要)` |
| 全文未获取 | `(全文未获取)` |
| 转引 | `〔转述自 X,未核原文〕` |
| 链接可能失效 | 附访问日期 |

## 红线

- **不编造**:不存在的论文、DOI、页码、URL 一个字都不写;
- **不装饰**:不为了"看起来有引用"而引不支撑该主张的源;
- 查不到 → 如实报"查不到",这是合格的交付,不是失败。
