---
name: draft-critique
description: >-
  Separate writing from criticism: dispatch an independent critic with delegate, and make the
  criticism land on evidence and a fix. With several candidates, generate, critique, then rank with
  one ruler to produce a comparison table. Use when the output will be judged, or when the user asks
  for a review.
---

# draft-critique —— 生成、批评、排名

自己写的稿子自己挑不出错 —— 批评者要**独立的上下文**,只有文本和标准。

## actor-critic(写完一篇就走一遍)

1. **写**(actor):按要求产出稿子,附**验收标准清单**(可检查的条目);
2. **派批评者**(critic):用 `delegate` 派一个子代理,给它:
   - 原始要求(不是你的解读);
   - 验收标准清单;
   - 稿子全文(**不给它你的写作过程** —— 它只需要看到成品);
   - 明确要它输出:`每条问题 = 位置(哪条主张/哪一段)+ 证据 + 修法`;
3. **回应批评**:逐条 `接受并改` / `不接受,理由是…`(引用文本证据)——
   静默忽略批评和无脑全收同样错;
4. 修订后的稿子 + 批评与回应记录一起交付(记录本身是质量证据)。

### 派之前先看预算(子代理不会回来讨价还价)

`delegate` 的子代理有硬上限:**12 步、约 15 分钟**,到点就停,不会续期。所以任务
要**小到能装进预算**:

- 只给它**成品 + 标准**,不要让它顺手去查全库文献或重做检索 —— 那样 12 步根本不够,
  它会在最后一步被砍断,而你在等的时候**看不到它在干什么**;
- 需要边查边写的活,先由你自己查完,再把材料摘进任务里给它;
- 它跑的时候**静默**,但每一步都写进 `.ngu-subtasks/` 下的 trace 文件,结果里带着
  路径 —— 等太久就直接读那个文件看它卡在哪;
- 结果里若是 `spent its 12-step budget` / `wall-clock budget ran out`,那不是批评,
  是**没做完**:把任务拆小重派,或自己改。

## 生成 → 批评 → 排名(≥2 个候选)

1. **先定尺子**:验收标准在看到答案**之前**定好(先看答案再定标准 =
   为想要的答案量身定做);
2. **生成**:≥2 个候选各自独立产出(不同的 delegate 或逐次生成,互不参考);
3. **同尺批评**:同一 prompt、同一标准逐个批评;
4. **排名表**:候选 × 标准的矩阵 + 一句"选它,因为…;放弃了…,代价是…"。

## 批评的合格线

- 落到**具体位置**:说"第三节的因果推断"而不是"有些地方不严谨";
- 带**证据**:引原文、引数据、指出反例;
- 给**修法**:怎么改能过标准 —— 只挑错不给路的批评价值减半;
- 分严重度:`致命 / 必改 / 建议`,让修订有顺序。
